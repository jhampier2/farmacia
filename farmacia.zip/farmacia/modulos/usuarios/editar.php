<?php
include '../../seguridad.php';
include '../../conexion.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: listar.php");
    exit;
}

$id = $_GET['id'];
$errores = [];

// Obtener datos actuales del usuario
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->execute([$id]);
$usuarioData = $stmt->fetch();

if (!$usuarioData) {
    echo "Usuario no encontrado.";
    exit;
}

// Si se envía el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);
    $correo = trim($_POST['correo']);
    $rol_id = $_POST['rol_id'];
    $estado = $_POST['estado'];
    $nueva_clave = $_POST['clave'];

    if (!$nombre) $errores[] = "El nombre es obligatorio.";
    if (!$rol_id) $errores[] = "Debe seleccionar un rol.";
    if (!$estado) $errores[] = "Debe seleccionar un estado.";
    if ($correo && !filter_var($correo, FILTER_VALIDATE_EMAIL)) $errores[] = "Correo no válido.";

    if (empty($errores)) {
        if ($nueva_clave) {
            $hash = password_hash($nueva_clave, PASSWORD_DEFAULT);
            $sql = "UPDATE usuarios SET nombre = ?, correo = ?, rol_id = ?, estado = ?, clave = ? WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$nombre, $correo, $rol_id, $estado, $hash, $id]);
        } else {
            $sql = "UPDATE usuarios SET nombre = ?, correo = ?, rol_id = ?, estado = ? WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$nombre, $correo, $rol_id, $estado, $id]);
        }
        header("Location: listar.php");
        exit;
    }
} else {
    // Si no se envió el formulario, mostrar los valores actuales
    $nombre = $usuarioData['nombre'];
    $correo = $usuarioData['correo'];
    $rol_id = $usuarioData['rol_id'];
    $estado = $usuarioData['estado'];
}

// Obtener roles disponibles
$roles = $pdo->query("SELECT id, nombre FROM roles ORDER BY nombre")->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Usuario</title>
    <link rel="stylesheet" href="../../estilos/style.css">
    <style>
        .form-container {
            max-width: 600px;
            margin: 30px auto;
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }
        input, select {
            width: 100%;
            padding: 8px;
            margin-top: 3px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            font-weight: bold;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background: #0056b3;
        }
        .error {
            background: #ffe1e1;
            color: #a94442;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #d9534f;
            border-radius: 4px;
        }
        .back-link {
            display: inline-block;
            margin-top: 15px;
            color: #007bff;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="form-container">
    <h2>Editar Usuario</h2>

    <?php if ($errores): ?>
        <div class="error">
            <ul>
                <?php foreach ($errores as $e): ?>
                    <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST">
        <label>Nombre:
            <input type="text" name="nombre" value="<?= htmlspecialchars($nombre) ?>" required>
        </label>

        <label>Usuario (no editable):
            <input type="text" value="<?= htmlspecialchars($usuarioData['usuario']) ?>" disabled>
        </label>

        <label>Correo:
            <input type="email" name="correo" value="<?= htmlspecialchars($correo) ?>">
        </label>

        <label>Nuevo contraseña (opcional):
            <input type="password" name="clave" placeholder="Dejar en blanco para no cambiar">
        </label>

        <label>Rol:
            <select name="rol_id" required>
                <option value="">--Seleccione--</option>
                <?php foreach ($roles as $r): ?>
                    <option value="<?= $r['id'] ?>" <?= ($rol_id == $r['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($r['nombre']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>

        <label>Estado:
            <select name="estado" required>
                <option value="">--Seleccione--</option>
                <option value="Activo" <?= ($estado == 'Activo') ? 'selected' : '' ?>>Activo</option>
                <option value="Inactivo" <?= ($estado == 'Inactivo') ? 'selected' : '' ?>>Inactivo</option>
            </select>
        </label>

        <button type="submit">Guardar cambios</button>
    </form>

    <a href="listar.php" class="back-link">← Volver a la lista</a>
</div>
</body>
</html>
