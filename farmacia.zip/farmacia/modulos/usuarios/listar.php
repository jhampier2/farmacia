<?php
include '../../seguridad.php';

// Solo administrador (rol_id = 1) puede acceder
if ($rol_id != 1) {
    echo "Acceso no autorizado. Tu rol es: " . ($rol_id ?? 'desconocido');
    exit;
}

// Obtener usuarios con su rol
$stmt = $pdo->query("
    SELECT u.id, u.nombre, u.usuario, u.correo, u.estado, r.nombre AS rol
    FROM usuarios u
    LEFT JOIN roles r ON u.rol_id = r.id
    ORDER BY u.nombre ASC
");
$usuarios = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8" />
<title>Lista de Usuarios</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background: #f4f6f8;
        margin: 0; padding: 20px;
    }
    .container {
        max-width: 900px;
        margin: auto;
        background: #fff;
        padding: 25px;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgb(0 0 0 / 0.1);
    }
    h1 {
        margin-bottom: 20px;
        color: #333;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
    }
    th, td {
        padding: 12px 15px;
        border-bottom: 1px solid #ddd;
        text-align: left;
    }
    th {
        background: #007bff;
        color: white;
    }
    tbody tr:hover {
        background: #f1f9ff;
    }
    a.button {
        display: inline-block;
        padding: 10px 15px;
        margin-bottom: 15px;
        background-color: #28a745;
        color: white;
        border-radius: 5px;
        text-decoration: none;
        font-weight: bold;
        transition: background-color 0.3s ease;
    }
    a.button:hover {
        background-color: #218838;
    }
    .action-btn {
        padding: 6px 10px;
        margin-right: 5px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        color: white;
        font-size: 14px;
        font-weight: 600;
        text-decoration: none;
    }
    .edit-btn {
        background-color: #007bff;
    }
    .edit-btn:hover {
        background-color: #0056b3;
    }
    .delete-btn {
        background-color: #dc3545;
    }
    .delete-btn:hover {
        background-color: #b02a37;
    }
    .back-link {
        display: inline-block;
        margin-top: 10px;
        color: #555;
        text-decoration: none;
    }
    .back-link:hover {
        text-decoration: underline;
    }
</style>
<script>
    function confirmarEliminar(nombre) {
        return confirm('¿Seguro que deseas eliminar al usuario "' + nombre + '"?');
    }
</script>
</head>
<body>
<div class="container">
    <h1>Usuarios Registrados</h1>
    <a href="agregar.php" class="button">➕ Nuevo Usuario</a>
    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Usuario</th>
                <th>Correo</th>
                <th>Estado</th>
                <th>Rol</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($usuarios) === 0): ?>
                <tr><td colspan="6" style="text-align:center; color:#777;">No hay usuarios registrados.</td></tr>
            <?php else: ?>
                <?php foreach ($usuarios as $u): ?>
                <tr>
                    <td><?= htmlspecialchars($u['nombre']) ?></td>
                    <td><?= htmlspecialchars($u['usuario']) ?></td>
                    <td><?= htmlspecialchars($u['correo']) ?></td>
                    <td><?= htmlspecialchars($u['estado']) ?></td>
                    <td><?= htmlspecialchars($u['rol']) ?></td>
                    <td>
                        <a href="editar.php?id=<?= $u['id'] ?>" class="action-btn edit-btn">✏️ Editar</a>
                        <a href="eliminar.php?id=<?= $u['id'] ?>" class="action-btn delete-btn" onclick="return confirmarEliminar('<?= htmlspecialchars($u['nombre']) ?>')">🗑 Eliminar</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
    <a href="../../dashboard.php" class="back-link">← Volver al panel principal</a>
</div>
</body>
</html>
