<?php
include '../../seguridad.php';
include '../../conexion.php';

// Verificar que el ID recibido es válido
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: listar.php");
    exit;
}

$id = $_GET['id'];

// Evitar que el admin actual se elimine a sí mismo
if ($_SESSION['usuario_id'] == $id) {
    echo "❌ No puedes eliminar tu propia cuenta.";
    exit;
}

// Verificar si el usuario existe
$stmt = $pdo->prepare("SELECT id FROM usuarios WHERE id = ?");
$stmt->execute([$id]);

if ($stmt->rowCount() === 0) {
    echo "❌ Usuario no encontrado.";
    exit;
}

// Eliminar usuario
$stmt = $pdo->prepare("DELETE FROM usuarios WHERE id = ?");
$stmt->execute([$id]);

// Redirigir al listado
header("Location: listar.php");
exit;
?>