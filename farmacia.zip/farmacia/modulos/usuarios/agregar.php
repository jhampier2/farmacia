<?php
include '../../seguridad.php';
include '../../conexion.php';

$errores = [];
$nombre = $usuario = $clave = $correo = $rol_id = $estado = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);
    $usuario = trim($_POST['usuario']);
    $clave = $_POST['clave'];
    $correo = trim($_POST['correo']);
    $rol_id = $_POST['rol_id'];
    $estado = $_POST['estado'];

    if (!$nombre) $errores[] = "El nombre es obligatorio.";
    if (!$usuario) $errores[] = "El usuario es obligatorio.";
    if (!$clave) $errores[] = "La contraseña es obligatoria.";
    if (!$rol_id) $errores[] = "Debe seleccionar un rol.";
    if (!$estado) $errores[] = "Debe seleccionar un estado.";

    // Validar email si se ingresó
    if ($correo && !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        $errores[] = "Correo no válido.";
    }

    // Verificar que el usuario no esté duplicado
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE usuario = ?");
    $stmt->execute([$usuario]);
    if ($stmt->rowCount() > 0) {
        $errores[] = "El nombre de usuario ya está en uso.";
    }

    if (empty($errores)) {
        $hash = password_hash($clave, PASSWORD_DEFAULT);
        $sql = "INSERT INTO usuarios (nombre, usuario, clave, correo, rol_id, estado) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$nombre, $usuario, $hash, $correo, $rol_id, $estado]);
        header("Location: listar.php");
        exit;
    }
}

// Obtener roles disponibles
$roles = $pdo->query("SELECT id, nombre FROM roles ORDER BY nombre")->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Usuario</title>
    <link rel="stylesheet" href="../../estilos/style.css">
    <style>
        .form-container {
            max-width: 600px;
            margin: 30px auto;
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }
        input, select {
            width: 100%;
            padding: 8px;
            margin-top: 3px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            font-weight: bold;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background: #0056b3;
        }
        .error {
            background: #ffe1e1;
            color: #a94442;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #d9534f;
            border-radius: 4px;
        }
        .back-link {
            display: inline-block;
            margin-top: 15px;
            color: #007bff;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="form-container">
    <h2>Agregar Usuario</h2>

    <?php if ($errores): ?>
        <div class="error">
            <ul>
                <?php foreach ($errores as $e): ?>
                    <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST">
        <label>Nombre:
            <input type="text" name="nombre" value="<?= htmlspecialchars($nombre) ?>" required>
        </label>

        <label>Usuario:
            <input type="text" name="usuario" value="<?= htmlspecialchars($usuario) ?>" required>
        </label>

        <label>Contraseña:
            <input type="password" name="clave" required>
        </label>

        <label>Correo:
            <input type="email" name="correo" value="<?= htmlspecialchars($correo) ?>">
        </label>

        <label>Rol:
            <select name="rol_id" required>
                <option value="">--Seleccione--</option>
                <?php foreach ($roles as $r): ?>
                    <option value="<?= $r['id'] ?>" <?= ($rol_id == $r['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($r['nombre']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>

        <label>Estado:
            <select name="estado" required>
                <option value="">--Seleccione--</option>
                <option value="Activo" <?= ($estado == 'Activo') ? 'selected' : '' ?>>Activo</option>
                <option value="Inactivo" <?= ($estado == 'Inactivo') ? 'selected' : '' ?>>Inactivo</option>
            </select>
        </label>

        <button type="submit">Guardar</button>
    </form>

    <a href="listar.php" class="back-link">← Volver a la lista</a>
</div>
</body>
</html>
