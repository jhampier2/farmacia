<?php
include '../../seguridad.php';
include '../../conexion.php';

if (!isset($_GET['id'])) {
    header("Location: listar.php");
    exit;
}

$id = $_GET['id'];

// Verificar si el médico existe
$stmt = $pdo->prepare("SELECT id FROM medicos WHERE id = ?");
$stmt->execute([$id]);
if ($stmt->rowCount() === 0) {
    header("Location: listar.php");
    exit;
}

// Eliminar médico
$stmt = $pdo->prepare("DELETE FROM medicos WHERE id = ?");
$stmt->execute([$id]);

header("Location: listar.php");
exit;
