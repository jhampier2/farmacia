<?php
include '../../seguridad.php';
include '../../conexion.php';

$errores = [];
$usuario_id = $especialidad_id = $cmp = "";

// Obtener usuarios y especialidades para selects
$usuarios = $pdo->query("SELECT id, nombre FROM usuarios ORDER BY nombre ASC")->fetchAll();
$especialidades = $pdo->query("SELECT id, nombre FROM especialidades ORDER BY nombre ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario_id = $_POST['usuario_id'];
    $especialidad_id = $_POST['especialidad_id'];
    $cmp = trim($_POST['cmp']);

    if (!$usuario_id) $errores[] = "Seleccione un usuario.";
    if (!$especialidad_id) $errores[] = "Seleccione una especialidad.";
    if (!$cmp) $errores[] = "El CMP es obligatorio.";

    // Validar CMP único
    $stmt = $pdo->prepare("SELECT id FROM medicos WHERE cmp = ?");
    $stmt->execute([$cmp]);
    if ($stmt->rowCount() > 0) $errores[] = "El CMP ya está registrado.";

    if (empty($errores)) {
        $sql = "INSERT INTO medicos (usuario_id, especialidad_id, cmp) VALUES (?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$usuario_id, $especialidad_id, $cmp]);
        header("Location: listar.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><title>Agregar Médico</title><link rel="stylesheet" href="../../estilos/style.css"></head>
<body>
<h2>Agregar Médico</h2>

<?php if ($errores): ?>
<div class="error"><ul><?php foreach ($errores as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul></div>
<?php endif; ?>

<form method="POST" action="agregar.php" novalidate>
<label>Usuario:<br>
    <select name="usuario_id" required>
        <option value="">--Seleccione--</option>
        <?php foreach ($usuarios as $u): ?>
        <option value="<?= $u['id'] ?>" <?= $usuario_id == $u['id'] ? 'selected' : '' ?>><?= htmlspecialchars($u['nombre']) ?></option>
        <?php endforeach; ?>
    </select>
</label><br>

<label>Especialidad:<br>
    <select name="especialidad_id" required>
        <option value="">--Seleccione--</option>
        <?php foreach ($especialidades as $e): ?>
        <option value="<?= $e['id'] ?>" <?= $especialidad_id == $e['id'] ? 'selected' : '' ?>><?= htmlspecialchars($e['nombre']) ?></option>
        <?php endforeach; ?>
    </select>
</label><br>

<label>CMP:<br><input type="text" name="cmp" value="<?= htmlspecialchars($cmp) ?>" required></label><br>

<button type="submit">Guardar</button>
</form>
<br><a href="listar.php">Volver a la lista</a>
</body>
</html>
