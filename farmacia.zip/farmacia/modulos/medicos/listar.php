<?php
include '../../seguridad.php';
include '../../conexion.php';

// Consulta para obtener médicos con sus usuarios y especialidades
$sql = "SELECT m.id, u.nombre AS nombre_usuario, e.nombre AS especialidad, m.cmp
        FROM medicos m
        LEFT JOIN usuarios u ON m.usuario_id = u.id
        LEFT JOIN especialidades e ON m.especialidad_id = e.id
        ORDER BY u.nombre ASC";
$stmt = $pdo->query($sql);
$medicos = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Médicos - Listar</title>
    <link rel="stylesheet" href="../../estilos/style.css">
    <style>
        .container {
            max-width: 900px;
            margin: 30px auto;
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        a.button {
            display: inline-block;
            padding: 10px 15px;
            background-color: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        a.button:hover {
            background-color: #218838;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            border-bottom: 1px solid #ccc;
            padding: 12px 15px;
            text-align: left;
        }
        th {
            background: #007bff;
            color: white;
        }
        td a {
            margin-right: 8px;
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
        }
        td a:hover {
            text-decoration: underline;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #007bff;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Lista de Médicos</h2>

    <a href="agregar.php" class="button">➕ Agregar nuevo médico</a>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Especialidad</th>
                <th>CMP</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($medicos) === 0): ?>
                <tr><td colspan="5" style="text-align:center; color:#777;">No hay médicos registrados.</td></tr>
            <?php else: ?>
                <?php foreach ($medicos as $m): ?>
                <tr>
                    <td><?= htmlspecialchars($m['id']) ?></td>
                    <td><?= htmlspecialchars($m['nombre_usuario']) ?></td>
                    <td><?= htmlspecialchars($m['especialidad']) ?></td>
                    <td><?= htmlspecialchars($m['cmp']) ?></td>
                    <td>
                        <a href="editar.php?id=<?= $m['id'] ?>">✏️ Editar</a>
                        <a href="eliminar.php?id=<?= $m['id'] ?>" onclick="return confirm('¿Eliminar médico?');">🗑 Eliminar</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <a href="../../dashboard.php" class="back-link">← Volver al panel</a>
</div>
</body>
</html>
