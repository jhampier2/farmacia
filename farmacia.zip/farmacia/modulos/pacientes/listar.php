<?php
include '../../seguridad.php';

// Verificar que solo el admin acceda
if ($rol_id != 1) {
    echo "Acceso no autorizado. Tu rol es: " . htmlspecialchars($rol_id);
    exit;
}

// Obtener lista de pacientes
$stmt = $pdo->query("SELECT id, nombre, dni, telefono, direccion FROM pacientes ORDER BY nombre ASC");
$pacientes = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Pacientes</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #eef2f7;
            margin: 0; padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: auto;
            background: #fff;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        h1 {
            margin-bottom: 20px;
            color: #333;
        }
        a.boton {
            display: inline-block;
            background: #28a745;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 5px;
            margin-bottom: 15px;
        }
        a.boton:hover {
            background: #218838;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            border-bottom: 1px solid #ccc;
            padding: 12px 15px;
            text-align: left;
        }
        th {
            background: #007bff;
            color: white;
        }
        .acciones a {
            margin-right: 5px;
            padding: 6px 10px;
            border-radius: 4px;
            font-size: 13px;
            color: white;
            text-decoration: none;
        }
        .edit {
            background: #007bff;
        }
        .delete {
            background: #dc3545;
        }
        .acciones a:hover {
            opacity: 0.85;
        }
        .back-link {
            display: inline-block;
            margin-top: 15px;
            color: #007bff;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Pacientes Registrados</h1>

    <a href="agregar.php" class="boton">➕ Nuevo Paciente</a>

    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>DNI</th>
                <th>Teléfono</th>
                <th>Dirección</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($pacientes) === 0): ?>
                <tr><td colspan="5" style="text-align:center; color:#777;">No hay pacientes registrados.</td></tr>
            <?php else: ?>
                <?php foreach ($pacientes as $p): ?>
                <tr>
                    <td><?= htmlspecialchars($p['nombre']) ?></td>
                    <td><?= htmlspecialchars($p['dni']) ?></td>
                    <td><?= htmlspecialchars($p['telefono']) ?></td>
                    <td><?= htmlspecialchars($p['direccion']) ?></td>
                    <td class="acciones">
                        <a class="edit" href="editar.php?id=<?= $p['id'] ?>">✏️ Editar</a>
                        <a class="delete" href="eliminar.php?id=<?= $p['id'] ?>" onclick="return confirm('¿Deseas eliminar este paciente?')">🗑 Eliminar</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <a href="../../dashboard.php" class="back-link">← Volver al panel</a>
</div>
</body>
</html>
