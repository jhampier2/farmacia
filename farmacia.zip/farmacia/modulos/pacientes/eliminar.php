<?php
include '../../seguridad.php';
include '../../conexion.php';

if (!isset($_GET['id'])) {
    header("Location: listar.php");
    exit;
}

$id = $_GET['id'];

// Verificar paciente existe
$stmt = $pdo->prepare("SELECT id FROM pacientes WHERE id = ?");
$stmt->execute([$id]);
if ($stmt->rowCount() === 0) {
    header("Location: listar.php");
    exit;
}

// Eliminar paciente
$stmt = $pdo->prepare("DELETE FROM pacientes WHERE id = ?");
$stmt->execute([$id]);

header("Location: listar.php");
exit;
