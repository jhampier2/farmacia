<?php
include '../../seguridad.php';
include '../../conexion.php';

if (!isset($_GET['id'])) {
    header("Location: listar.php");
    exit;
}

$id = $_GET['id'];
$errores = [];

$stmt = $pdo->prepare("SELECT * FROM pacientes WHERE id = ?");
$stmt->execute([$id]);
$paciente = $stmt->fetch();

if (!$paciente) {
    echo "Paciente no encontrado";
    exit;
}

$nombre = $paciente['nombre'];
$dni = $paciente['dni'];
$fecha_nacimiento = $paciente['fecha_nacimiento'];
$sexo = $paciente['sexo'];
$telefono = $paciente['telefono'];
$correo = $paciente['correo'];
$direccion = $paciente['direccion'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);
    $dni_post = trim($_POST['dni']);
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $sexo = $_POST['sexo'];
    $telefono = trim($_POST['telefono']);
    $correo = trim($_POST['correo']);
    $direccion = trim($_POST['direccion']);

    if (!$nombre) $errores[] = "El nombre es obligatorio.";
    if (!$dni_post) $errores[] = "El DNI es obligatorio.";
    if (!in_array($sexo, ['M', 'F'])) $errores[] = "Seleccione un sexo válido.";
    if ($correo && !filter_var($correo, FILTER_VALIDATE_EMAIL)) $errores[] = "Correo inválido.";

    // Verificar dni único (excepto este paciente)
    $stmt = $pdo->prepare("SELECT id FROM pacientes WHERE dni = ? AND id != ?");
    $stmt->execute([$dni_post, $id]);
    if ($stmt->rowCount() > 0) $errores[] = "El DNI ya está registrado.";

    if (empty($errores)) {
        $sql = "UPDATE pacientes SET nombre = ?, dni = ?, fecha_nacimiento = ?, sexo = ?, telefono = ?, correo = ?, direccion = ? WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$nombre, $dni_post, $fecha_nacimiento, $sexo, $telefono, $correo, $direccion, $id]);
        header("Location: listar.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><title>Editar Paciente</title><link rel="stylesheet" href="../../estilos/style.css"></head>
<body>
<h2>Editar Paciente</h2>

<?php if ($errores): ?>
<div class="error"><ul>
<?php foreach ($errores as $e): ?>
    <li><?= htmlspecialchars($e) ?></li>
<?php endforeach; ?>
</ul></div>
<?php endif; ?>

<form method="POST" action="editar.php?id=<?= $id ?>" novalidate>
<label>Nombre:<br><input type="text" name="nombre" value="<?= htmlspecialchars($nombre) ?>" required></label><br>
<label>DNI:<br><input type="text" name="dni" value="<?= htmlspecialchars($dni) ?>" required></label><br>
<label>Fecha Nacimiento:<br><input type="date" name="fecha_nacimiento" value="<?= htmlspecialchars($fecha_nacimiento) ?>"></label><br>
<label>Sexo:<br>
    <select name="sexo" required>
        <option value="">--Seleccione--</option>
        <option value="M" <?= $sexo === 'M' ? 'selected' : '' ?>>Masculino</option>
        <option value="F" <?= $sexo === 'F' ? 'selected' : '' ?>>Femenino</option>
    </select>
</label><br>
<label>Teléfono:<br><input type="text" name="telefono" value="<?= htmlspecialchars($telefono) ?>"></label><br>
<label>Correo:<br><input type="email" name="correo" value="<?= htmlspecialchars($correo) ?>"></label><br>
<label>Dirección:<br><textarea name="direccion"><?= htmlspecialchars($direccion) ?></textarea></label><br>
<button type="submit">Guardar Cambios</button>
</form>
<br><a href="listar.php">Volver a la lista</a>
</body>
</html>
