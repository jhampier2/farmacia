<?php
include '../../seguridad.php';
include '../../conexion.php';

$errores = [];
$nombre = $dni = $fecha_nacimiento = $sexo = $telefono = $correo = $direccion = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);
    $dni = trim($_POST['dni']);
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $sexo = $_POST['sexo'];
    $telefono = trim($_POST['telefono']);
    $correo = trim($_POST['correo']);
    $direccion = trim($_POST['direccion']);

    if (!$nombre) $errores[] = "El nombre es obligatorio.";
    if (!$dni) $errores[] = "El DNI es obligatorio.";
    if (!in_array($sexo, ['M', 'F'])) $errores[] = "Seleccione un sexo válido.";
    if ($correo && !filter_var($correo, FILTER_VALIDATE_EMAIL)) $errores[] = "Correo inválido.";

    // Verificar dni único
    $stmt = $pdo->prepare("SELECT id FROM pacientes WHERE dni = ?");
    $stmt->execute([$dni]);
    if ($stmt->rowCount() > 0) $errores[] = "El DNI ya está registrado.";

    if (empty($errores)) {
        $sql = "INSERT INTO pacientes (nombre, dni, fecha_nacimiento, sexo, telefono, correo, direccion) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$nombre, $dni, $fecha_nacimiento, $sexo, $telefono, $correo, $direccion]);
        header("Location: listar.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Paciente</title>
    <link rel="stylesheet" href="../../estilos/style2.css">
</head>
<body>

<h2>Agregar Paciente</h2>

<?php if ($errores): ?>
    <div class="error">
        <ul>
            <?php foreach ($errores as $e): ?>
                <li><?= htmlspecialchars($e) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form method="POST" action="agregar.php" novalidate>
    <label>Nombre:
        <input type="text" name="nombre" value="<?= htmlspecialchars($nombre) ?>" required>
    </label>

    <label>DNI:
        <input type="text" name="dni" value="<?= htmlspecialchars($dni) ?>" required>
    </label>

    <label>Fecha de Nacimiento:
        <input type="date" name="fecha_nacimiento" value="<?= htmlspecialchars($fecha_nacimiento) ?>">
    </label>

    <label>Sexo:
        <select name="sexo" required>
            <option value="">--Seleccione--</option>
            <option value="M" <?= $sexo === 'M' ? 'selected' : '' ?>>Masculino</option>
            <option value="F" <?= $sexo === 'F' ? 'selected' : '' ?>>Femenino</option>
        </select>
    </label>

    <label>Teléfono:
        <input type="text" name="telefono" value="<?= htmlspecialchars($telefono) ?>">
    </label>

    <label>Correo:
        <input type="email" name="correo" value="<?= htmlspecialchars($correo) ?>">
    </label>

    <label>Dirección:
        <textarea name="direccion"><?= htmlspecialchars($direccion) ?></textarea>
    </label>

    <button type="submit">Guardar</button>
</form>

<a href="listar.php">← Volver a la lista</a>

</body>
</html>
