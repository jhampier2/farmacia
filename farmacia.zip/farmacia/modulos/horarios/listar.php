<?php
include '../../seguridad.php';
include '../../conexion.php';

// Consulta con JOIN para mostrar nombre del médico
$sql = "SELECT h.id, h.dia, h.hora_inicio, h.hora_fin, m.id AS medico_id, u.nombre AS nombre_medico
        FROM horarios h
        INNER JOIN medicos m ON h.medico_id = m.id
        INNER JOIN usuarios u ON m.usuario_id = u.id
        ORDER BY u.nombre, FIELD(h.dia, 'Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'), h.hora_inicio";
$stmt = $pdo->query($sql);
$horarios = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Horarios - Listar</title>
<link rel="stylesheet" href="../../estilos/style.css">
</head>
<body>
<h2>Lista de Horarios</h2>
<a href="agregar.php">Agregar horario</a>
<table border="1" cellpadding="8" cellspacing="0">
<thead>
<tr>
    <th>Médico</th>
    <th>Día</th>
    <th>Hora Inicio</th>
    <th>Hora Fin</th>
    <th>Acciones</th>
</tr>
</thead>
<tbody>
<?php foreach ($horarios as $h): ?>
<tr>
    <td><?= htmlspecialchars($h['nombre_medico']) ?></td>
    <td><?= htmlspecialchars($h['dia']) ?></td>
    <td><?= htmlspecialchars($h['hora_inicio']) ?></td>
    <td><?= htmlspecialchars($h['hora_fin']) ?></td>
    <td>
        <a href="editar.php?id=<?= $h['id'] ?>">Editar</a> |
        <a href="eliminar.php?id=<?= $h['id'] ?>" onclick="return confirm('¿Eliminar horario?');">Eliminar</a>
    </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
<br><a href="../../dashboard.php">Volver al panel</a>
</body>
</html>
