<?php
include '../../seguridad.php';
include '../../conexion.php';

if (!isset($_GET['id'])) {
    header("Location: listar.php");
    exit;
}

$id = $_GET['id'];

// Verificar horario existe
$stmt = $pdo->prepare("SELECT id FROM horarios WHERE id = ?");
$stmt->execute([$id]);
if ($stmt->rowCount() === 0) {
    header("Location: listar.php");
    exit;
}

// Eliminar horario
$stmt = $pdo->prepare("DELETE FROM horarios WHERE id = ?");
$stmt->execute([$id]);

header("Location: listar.php");
exit;
