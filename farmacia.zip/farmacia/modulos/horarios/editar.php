<?php
include '../../seguridad.php';
include '../../conexion.php';

if (!isset($_GET['id'])) {
    header("Location: listar.php");
    exit;
}

$id = $_GET['id'];
$errores = [];

// Cargar horario actual
$stmt = $pdo->prepare("SELECT * FROM horarios WHERE id = ?");
$stmt->execute([$id]);
$horario = $stmt->fetch();

if (!$horario) {
    echo "Horario no encontrado";
    exit;
}

$medico_id = $horario['medico_id'];
$dia = $horario['dia'];
$hora_inicio = $horario['hora_inicio'];
$hora_fin = $horario['hora_fin'];

// Obtener lista médicos
$medicos = $pdo->query("
    SELECT m.id, u.nombre 
    FROM medicos m
    INNER JOIN usuarios u ON m.usuario_id = u.id
    ORDER BY u.nombre ASC
")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $medico_id = $_POST['medico_id'];
    $dia = $_POST['dia'];
    $hora_inicio = $_POST['hora_inicio'];
    $hora_fin = $_POST['hora_fin'];

    if (!$medico_id) $errores[] = "Seleccione un médico.";
    if (!$dia) $errores[] = "Seleccione un día.";
    if (!$hora_inicio) $errores[] = "Ingrese hora de inicio.";
    if (!$hora_fin) $errores[] = "Ingrese hora de fin.";
    if ($hora_inicio >= $hora_fin) $errores[] = "La hora de fin debe ser mayor que la hora de inicio.";

    // Validar solapamiento excluyendo este horario
    $sql_check = "SELECT * FROM horarios WHERE medico_id = ? AND dia = ? 
                  AND id != ? 
                  AND ((hora_inicio < ? AND hora_fin > ?) OR (hora_inicio < ? AND hora_fin > ?))";
    $stmt_check = $pdo->prepare($sql_check);
    $stmt_check->execute([$medico_id, $dia, $id, $hora_fin, $hora_fin, $hora_inicio, $hora_inicio]);
    if ($stmt_check->rowCount() > 0) {
        $errores[] = "El horario se solapa con otro existente para este médico.";
    }

    if (empty($errores)) {
        $sql = "UPDATE horarios SET medico_id = ?, dia = ?, hora_inicio = ?, hora_fin = ? WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$medico_id, $dia, $hora_inicio, $hora_fin, $id]);
        header("Location: listar.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Editar Horario</title>
<link rel="stylesheet" href="../../estilos/style.css">
</head>
<body>
<h2>Editar Horario</h2>

<?php if ($errores): ?>
<div class="error">
<ul>
<?php foreach ($errores as $error): ?>
<li><?= htmlspecialchars($error) ?></li>
<?php endforeach; ?>
</ul>
</div>
<?php endif; ?>

<form method="POST" action="editar.php?id=<?= $id ?>" novalidate>
<label>Médico:<br>
    <select name="medico_id" required>
        <option value="">--Seleccione--</option>
        <?php foreach ($medicos as $m): ?>
        <option value="<?= $m['id'] ?>" <?= $medico_id == $m['id'] ? 'selected' : '' ?>><?= htmlspecialchars($m['nombre']) ?></option>
        <?php endforeach; ?>
    </select>
</label><br>

<label>Día:<br>
    <select name="dia" required>
        <option value="">--Seleccione--</option>
        <option value="Lunes" <?= $dia == 'Lunes' ? 'selected' : '' ?>>Lunes</option>
        <option value="Martes" <?= $dia == 'Martes' ? 'selected' : '' ?>>Martes</option>
        <option value="Miércoles" <?= $dia == 'Miércoles' ? 'selected' : '' ?>>Miércoles</option>
        <option value="Jueves" <?= $dia == 'Jueves' ? 'selected' : '' ?>>Jueves</option>
        <option value="Viernes" <?= $dia == 'Viernes' ? 'selected' : '' ?>>Viernes</option>
        <option value="Sábado" <?= $dia == 'Sábado' ? 'selected' : '' ?>>Sábado</option>
    </select>
</label><br>

<label>Hora Inicio:<br>
    <input type="time" name="hora_inicio" value="<?= htmlspecialchars($hora_inicio) ?>" required>
</label><br>

<label>Hora Fin:<br>
    <input type="time" name="hora_fin" value="<?= htmlspecialchars($hora_fin) ?>" required>
</label><br>

<button type="submit">Guardar Cambios</button>
</form>

<br><a href="listar.php">Volver a la lista</a>
</body>
</html>
