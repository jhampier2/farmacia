<?php
include '../../seguridad.php';
include '../../conexion.php';

if (!isset($_GET['id'])) {
    header("Location: listar.php");
    exit;
}

$id = $_GET['id'];

$stmt = $pdo->prepare("SELECT id FROM citas WHERE id = ?");
$stmt->execute([$id]);
if ($stmt->rowCount() === 0) {
    header("Location: listar.php");
    exit;
}

$stmt = $pdo->prepare("DELETE FROM citas WHERE id = ?");
$stmt->execute([$id]);

header("Location: listar.php");
exit;
