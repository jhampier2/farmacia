<?php
include '../../seguridad.php';
include '../../conexion.php';

$errores = [];
$paciente_id = $medico_id = $consultorio_id = $fecha = $hora = $motivo = "";

$pacientes = $pdo->query("SELECT id, nombre FROM pacientes ORDER BY nombre ASC")->fetchAll();
$medicos = $pdo->query("
    SELECT m.id, u.nombre 
    FROM medicos m 
    INNER JOIN usuarios u ON m.usuario_id = u.id 
    ORDER BY u.nombre ASC
")->fetchAll();
$consultorios = $pdo->query("SELECT id, nombre FROM consultorios ORDER BY nombre ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $paciente_id = $_POST['paciente_id'];
    $medico_id = $_POST['medico_id'];
    $consultorio_id = $_POST['consultorio_id'];
    $fecha = $_POST['fecha'];
    $hora = $_POST['hora'];
    $motivo = trim($_POST['motivo']);

    if (!$paciente_id) $errores[] = "Seleccione un paciente.";
    if (!$medico_id) $errores[] = "Seleccione un médico.";
    if (!$consultorio_id) $errores[] = "Seleccione un consultorio.";
    if (!$fecha) $errores[] = "Seleccione una fecha.";
    if (!$hora) $errores[] = "Seleccione una hora.";
    if (!$motivo) $errores[] = "Ingrese el motivo de la cita.";

    // Componer datetime
    $fecha_hora = $fecha . ' ' . $hora;

    // Validar disponibilidad (no solapar citas para el mismo médico)
    $sql_check = "SELECT * FROM citas WHERE medico_id = ? AND fecha = ? AND estado = 'Programada'";
    $stmt_check = $pdo->prepare($sql_check);
    $stmt_check->execute([$medico_id, $fecha_hora]);
    if ($stmt_check->rowCount() > 0) {
        $errores[] = "El médico ya tiene una cita programada en esa fecha y hora.";
    }

    if (empty($errores)) {
        $sql = "INSERT INTO citas (paciente_id, medico_id, consultorio_id, fecha, motivo, estado) VALUES (?, ?, ?, ?, ?, 'Programada')";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$paciente_id, $medico_id, $consultorio_id, $fecha_hora, $motivo]);
        header("Location: listar.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Agregar Cita</title>
<link rel="stylesheet" href="../../estilos/style.css">
</head>
<body>
<h2>Agregar Cita</h2>

<?php if ($errores): ?>
<div class="error"><ul>
<?php foreach ($errores as $error): ?>
    <li><?= htmlspecialchars($error) ?></li>
<?php endforeach; ?>
</ul></div>
<?php endif; ?>

<form method="POST" action="agregar.php" novalidate>
<label>Paciente:<br>
    <select name="paciente_id" required>
        <option value="">--Seleccione--</option>
        <?php foreach ($pacientes as $p): ?>
        <option value="<?= $p['id'] ?>" <?= $paciente_id == $p['id'] ? 'selected' : '' ?>><?= htmlspecialchars($p['nombre']) ?></option>
        <?php endforeach; ?>
    </select>
</label><br>

<label>Médico:<br>
    <select name="medico_id" required>
        <option value="">--Seleccione--</option>
        <?php foreach ($medicos as $m): ?>
        <option value="<?= $m['id'] ?>" <?= $medico_id == $m['id'] ? 'selected' : '' ?>><?= htmlspecialchars($m['nombre']) ?></option>
        <?php endforeach; ?>
    </select>
</label><br>

<label>Consultorio:<br>
    <select name="consultorio_id" required>
        <option value="">--Seleccione--</option>
        <?php foreach ($consultorios as $c): ?>
        <option value="<?= $c['id'] ?>" <?= $consultorio_id == $c['id'] ? 'selected' : '' ?>><?= htmlspecialchars($c['nombre']) ?></option>
        <?php endforeach; ?>
    </select>
</label><br>

<label>Fecha:<br>
    <input type="date" name="fecha" value="<?= htmlspecialchars($fecha) ?>" required>
</label><br>

<label>Hora:<br>
    <input type="time" name="hora" value="<?= htmlspecialchars($hora) ?>" required>
</label><br>

<label>Motivo:<br>
    <textarea name="motivo" required><?= htmlspecialchars($motivo) ?></textarea>
</label><br>

<button type="submit">Guardar</button>
</form>

<br><a href="listar.php">Volver a la lista</a>
</body>
</html>
