<?php
include '../../seguridad.php';
include '../../conexion.php';

if (!isset($_GET['id'])) {
    header("Location: listar.php");
    exit;
}

$id = $_GET['id'];
$errores = [];

$stmt = $pdo->prepare("SELECT * FROM citas WHERE id = ?");
$stmt->execute([$id]);
$cita = $stmt->fetch();

if (!$cita) {
    echo "Cita no encontrada";
    exit;
}

$paciente_id = $cita['paciente_id'];
$medico_id = $cita['medico_id'];
$consultorio_id = $cita['consultorio_id'];
$fecha_hora = $cita['fecha'];
$motivo = $cita['motivo'];
$estado = $cita['estado'];

// Separar fecha y hora
$fecha = substr($fecha_hora, 0, 10);
$hora = substr($fecha_hora, 11, 5);

$pacientes = $pdo->query("SELECT id, nombre FROM pacientes ORDER BY nombre ASC")->fetchAll();
$medicos = $pdo->query("
    SELECT m.id, u.nombre 
    FROM medicos m 
    INNER JOIN usuarios u ON m.usuario_id = u.id 
    ORDER BY u.nombre ASC
")->fetchAll();
$consultorios = $pdo->query("SELECT id, nombre FROM consultorios ORDER BY nombre ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $paciente_id = $_POST['paciente_id'];
    $medico_id = $_POST['medico_id'];
    $consultorio_id = $_POST['consultorio_id'];
    $fecha = $_POST['fecha'];
    $hora = $_POST['hora'];
    $motivo = trim($_POST['motivo']);
    $estado = $_POST['estado'];

    if (!$paciente_id) $errores[] = "Seleccione un paciente.";
    if (!$medico_id) $errores[] = "Seleccione un médico.";
    if (!$consultorio_id) $errores[] = "Seleccione un consultorio.";
    if (!$fecha) $errores[] = "Seleccione una fecha.";
    if (!$hora) $errores[] = "Seleccione una hora.";
    if (!$motivo) $errores[] = "Ingrese el motivo de la cita.";
    if (!in_array($estado, ['Programada', 'Cancelada', 'Atendida'])) $errores[] = "Estado inválido.";

    $fecha_hora_nueva = $fecha . ' ' . $hora;

    // Validar solapamiento excluyendo esta cita
    $sql_check = "SELECT * FROM citas WHERE medico_id = ? AND fecha = ? AND estado = 'Programada' AND id != ?";
    $stmt_check = $pdo->prepare($sql_check);
    $stmt_check->execute([$medico_id, $fecha_hora_nueva, $id]);
    if ($stmt_check->rowCount() > 0) {
        $errores[] = "El médico ya tiene una cita programada en esa fecha y hora.";
    }

    if (empty($errores)) {
        $sql = "UPDATE citas SET paciente_id = ?, medico_id = ?, consultorio_id = ?, fecha = ?, motivo = ?, estado = ? WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$paciente_id, $medico_id, $consultorio_id, $fecha_hora_nueva, $motivo, $estado, $id]);
        header("Location: listar.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Editar Cita</title>
<link rel="stylesheet" href="../../estilos/style.css">
</head>
<body>
<h2>Editar Cita</h2>

<?php if ($errores): ?>
<div class="error"><ul>
<?php foreach ($errores as $error): ?>
    <li><?= htmlspecialchars($error) ?></li>
<?php endforeach; ?>
</ul></div>
<?php endif; ?>

<form method="POST" action="editar.php?id=<?= $id ?>" novalidate>
<label>Paciente:<br>
    <select name="paciente_id" required>
        <option value="">--Seleccione--</option>
        <?php foreach ($pacientes as $p): ?>
        <option value="<?= $p['id'] ?>" <?= $paciente_id == $p['id'] ? 'selected' : '' ?>><?= htmlspecialchars($p['nombre']) ?></option>
        <?php endforeach; ?>
    </select>
</label><br>

<label>Médico:<br>
    <select name="medico_id" required>
        <option value="">--Seleccione--</option>
        <?php foreach ($medicos as $m): ?>
        <option value="<?= $m['id'] ?>" <?= $medico_id == $m['id'] ? 'selected' : '' ?>><?= htmlspecialchars($m['nombre']) ?></option>
        <?php endforeach; ?>
    </select>
</label><br>

<label>Consultorio:<br>
    <select name="consultorio_id" required>
        <option value="">--Seleccione--</option>
        <?php foreach ($consultorios as $c): ?>
        <option value="<?= $c['id'] ?>" <?= $consultorio_id == $c['id'] ? 'selected' : '' ?>><?= htmlspecialchars($c['nombre']) ?></option>
        <?php endforeach; ?>
    </select>
</label><br>

<label>Fecha:<br>
    <input type="date" name="fecha" value="<?= htmlspecialchars($fecha) ?>" required>
</label><br>

<label>Hora:<br>
    <input type="time" name="hora" value="<?= htmlspecialchars($hora) ?>" required>
</label><br>

<label>Motivo:<br>
    <textarea name="motivo" required><?= htmlspecialchars($motivo) ?></textarea>
</label><br>

<label>Estado:<br>
    <select name="estado" required>
        <option value="Programada" <?= $estado == 'Programada' ? 'selected' : '' ?>>Programada</option>
        <option value="Cancelada" <?= $estado == 'Cancelada' ? 'selected' : '' ?>>Cancelada</option>
        <option value="Atendida" <?= $estado == 'Atendida' ? 'selected' : '' ?>>Atendida</option>
    </select>
</label><br>

<button type="submit">Guardar Cambios</button>
</form>

<br><a href="listar.php">Volver a la lista</a>
</body>
</html>
