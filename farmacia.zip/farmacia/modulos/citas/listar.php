<?php
include '../../seguridad.php';
include '../../conexion.php';

$sql = "SELECT c.id, c.fecha, c.motivo, c.estado,
        p.nombre AS nombre_paciente,
        u.nombre AS nombre_medico,
        con.nombre AS consultorio
        FROM citas c
        LEFT JOIN pacientes p ON c.paciente_id = p.id
        LEFT JOIN medicos m ON c.medico_id = m.id
        LEFT JOIN usuarios u ON m.usuario_id = u.id
        LEFT JOIN consultorios con ON c.consultorio_id = con.id
        ORDER BY c.fecha DESC";

$stmt = $pdo->query($sql);
$citas = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Citas - Listar</title>
<link rel="stylesheet" href="../../estilos/style.css">
</head>
<body>
<h2>Lista de Citas</h2>
<a href="agregar.php">Agregar nueva cita</a>
<table border="1" cellpadding="8" cellspacing="0">
<thead>
<tr>
    <th>Paciente</th>
    <th>Médico</th>
    <th>Consultorio</th>
    <th>Fecha y Hora</th>
    <th>Motivo</th>
    <th>Estado</th>
    <th>Acciones</th>
</tr>
</thead>
<tbody>
<?php foreach ($citas as $c): ?>
<tr>
    <td><?= htmlspecialchars($c['nombre_paciente']) ?></td>
    <td><?= htmlspecialchars($c['nombre_medico']) ?></td>
    <td><?= htmlspecialchars($c['consultorio']) ?></td>
    <td><?= htmlspecialchars($c['fecha']) ?></td>
    <td><?= htmlspecialchars($c['motivo']) ?></td>
    <td><?= htmlspecialchars($c['estado']) ?></td>
    <td>
        <a href="editar.php?id=<?= $c['id'] ?>">Editar</a> |
        <a href="eliminar.php?id=<?= $c['id'] ?>" onclick="return confirm('¿Eliminar cita?');">Eliminar</a>
    </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
<br><a href="../../dashboard.php">Volver al panel</a>
</body>
</html>
