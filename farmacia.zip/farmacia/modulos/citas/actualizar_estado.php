<?php
include '../../seguridad.php';
include '../../conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cita_id = $_POST['id'] ?? null;
    $accion = $_POST['accion'] ?? '';

    // Validar valores
    if (!$cita_id || !in_array($accion, ['Atendida', 'Cancelada'])) {
        die('⚠️ Datos inválidos.');
    }

    $usuario_id = $_SESSION['usuario_id'];

    // Verificar si el usuario es médico y obtener su ID
    $stmt = $pdo->prepare("SELECT id FROM medicos WHERE usuario_id = ?");
    $stmt->execute([$usuario_id]);
    $medico = $stmt->fetch();

    if (!$medico) {
        die('🚫 No tienes permisos para modificar citas.');
    }

    $medico_id = $medico['id'];

    // Verificar si la cita le pertenece al médico
    $stmt = $pdo->prepare("SELECT id FROM citas WHERE id = ? AND medico_id = ?");
    $stmt->execute([$cita_id, $medico_id]);
    $cita = $stmt->fetch();

    if (!$cita) {
        die('❌ Esta cita no existe o no está asignada a ti.');
    }

    // Actualizar estado de la cita
    $stmt = $pdo->prepare("UPDATE citas SET estado = ? WHERE id = ?");
    if ($stmt->execute([$accion, $cita_id])) {
        header('Location: ../../panel_medico.php?mensaje=ok');
        exit;
    } else {
        die('❌ Error al actualizar la cita.');
    }

} else {
    die('🚫 Método no permitido.');
}
?>
